const express = require('express');
const router = express.Router();
const Registro = require('../models/registro.js');
const Habito = require('../models/habito.js');

// Normaliza para início do dia em UTC
function startOfDayUTC(date) {
  const d = new Date(date);
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

// Adiciona dias em UTC
function addDaysUTC(date, days) {
  const d = new Date(date);
  d.setUTCDate(d.getUTCDate() + days);
  return d;
}

// Domingo como início da semana em UTC
function startOfWeekUTC(date) {
  const d = startOfDayUTC(date);
  const day = d.getUTCDay(); // 0 = domingo
  d.setUTCDate(d.getUTCDate() - day); // volta até domingo
  return d;
}

router.get('/semana', async (req, res) => {
  try {
    // no futuro dá pra ler ini/fim de req.query
    const hoje = new Date();
    const inicioSemana = startOfWeekUTC(hoje);             // domingo 00:00 UTC
    const fimSemana = addDaysUTC(inicioSemana, 6);         // sábado 00:00 UTC
    fimSemana.setUTCHours(23, 59, 59, 999);                // fim do dia

    // Gera array de 7 dias (objetos Date)
    const diasArray = [];
    for (let i = 0; i < 7; i++) {
      diasArray.push(addDaysUTC(inicioSemana, i));
    }

    const habitos = await Habito.find().lean();

    const registros = await Registro.find({
      data: { $gte: inicioSemana, $lte: fimSemana },
      valor: true
    }).lean();

    const retornoHabitos = habitos.map(habito => {
      const progresso = Array(7).fill(false);

      registros
        .filter(r => r.habitoId.toString() === habito._id.toString())
        .forEach(r => {
          const regDate = startOfDayUTC(r.data);
          const diffMs = regDate.getTime() - inicioSemana.getTime();
          const index = Math.floor(diffMs / (1000 * 60 * 60 * 24)); // diferença em dias

          if (index >= 0 && index < 7) {
            progresso[index] = true;
          }
        });

      return {
        habitoId: habito._id,
        nome: habito.nome,
        progresso
      };
    });

    const datas = diasArray.map(d => d.toISOString().slice(0, 10)); // 'YYYY-MM-DD'

    res.json({
      datas,
      habitos: retornoHabitos
    });
  } catch (err) {
    console.error('Erro ao buscar progresso semanal:', err);
    res.status(500).json({ erro: 'Erro ao buscar progresso semanal' });
  }
});

module.exports = router;
