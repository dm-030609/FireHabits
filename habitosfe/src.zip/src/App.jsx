import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Navbar, Nav, ListGroup, ListGroupItem } from 'react-bootstrap';


function App() {
  const [habitos, setHabitos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Função para buscar os hábitos do backend
  useEffect(() => {
    const fetchHabitos = async () => {
      try {
        const response = await axios.get('http://localhost:3000/habitos');
        setHabitos(response.data);
        setLoading(false);
      } catch (err) {
        setError('Erro ao buscar os hábitos');
        setLoading(false);
      }
    };

    fetchHabitos(); // Chama a função para buscar os hábitos ao carregar o componente
  }, []);

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
        <div className="spinner-border" role="status">
          <span className="visually-hidden">Carregando...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div>
      {/* Menu de Navegação */}
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="#">HabitsApp</Navbar.Brand>
          <Navbar.Toggle aria-controls="navbar-nav" />
          <Navbar.Collapse id="navbar-nav">
            <Nav className="ml-auto">
              <Nav.Link href="#home">Início</Nav.Link>
              <Nav.Link href="#about">Sobre</Nav.Link>
              <Nav.Link href="#contact">Contato</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Conteúdo principal */}
      <Container className="mt-4">
        <h1>Lista de Hábitos</h1>
        <ListGroup>
          {habitos.map((habito, index) => (
            <ListGroupItem key={index} className="mb-2">
              <h5>{habito.nome}</h5>
              <p>{habito.descricao}</p>
              <p><strong>Frequência:</strong> {habito.frequencia}</p>
              <p><strong>Status:</strong> {habito.status}</p>
            </ListGroupItem>
          ))}
        </ListGroup>
      </Container>
    </div>
  );
}

export default App;
