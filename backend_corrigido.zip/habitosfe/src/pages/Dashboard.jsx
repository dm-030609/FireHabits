import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Container, Row, Col, Card, Spinner, Badge
} from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { listarHabitosLocal } from '../../indexedDB';
import { Flame } from 'lucide-react';

export default function Dashboard() {
  const [dados, setDados] = useState(null);
  const [loading, setLoading] = useState(true);
  const [offline, setOffline] = useState(false);
  const [progresso, setProgresso] = useState([]);

  useEffect(() => {
    const fetchDados = async () => {
      try {
        const res = await axios.get('http://localhost:3000/habitos/resumo');
        setDados(res.data);
        setOffline(false);
      } catch {
        const locais = await listarHabitosLocal();
        const ativos = locais.length;
        const concluidosHoje = locais.filter(h => h.status === 'Concluído').length;
        const pendentes = locais.filter(h => h.status === 'Pendente').length;
        const semana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        const semanaData = semana.map((dia, i) => ({
          dia,
          completados: Math.floor(Math.random() * 5)
        }));
        setDados({ ativos, concluidosHoje, pendentes, semana: semanaData });
        setOffline(true);
      } finally {
        setLoading(false);
      }
    };

    const fetchProgresso = async () => {
      try {
        const res = await axios.get('http://localhost:3000/habitos/progresso');
        setProgresso(res.data);
      } catch (err) {
        console.error('Erro ao buscar progresso:', err);
      }
    };

    fetchDados();
    fetchProgresso();
  }, []);

  if (loading) {
    return (
      <div className="text-center text-light mt-5">
        <Spinner animation="border" variant="danger" />
      </div>
    );
  }

  return (
    //<Container fluid className="bg-dark text-white min-vh-100 py-4">
    <div className="container-fluid bg-dark text-white min-vh-100 py-4 w-100">
      <h1 className="text-danger text-center mb-4">
        Painel de Controle {offline && <Badge bg="secondary">(Offline)</Badge>}
      </h1>

      <Row className="g-3 justify-content-center">
        <Col xs={12} md={4}>
          <Card className="bg-black text-white text-center shadow-sm h-100">
            <Card.Body>
              <Card.Title className="fw-bold">Hábitos Ativos</Card.Title>
              <Card.Text className="display-6 text-danger text-break">{dados.ativos}</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col xs={12} md={4}>
          <Card className="bg-secondary text-white text-center shadow-sm h-100">
            <Card.Body>
              <Card.Title className="fw-bold">Concluídos Hoje</Card.Title>
              <Card.Text className="display-6 text-break">{dados.concluidosHoje}</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col xs={12} md={4}>
          <Card className="bg-danger text-white text-center shadow-sm h-100">
            <Card.Body>
              <Card.Title className="fw-bold">Pendentes</Card.Title>
              <Card.Text className="display-6 text-break">{dados.pendentes}</Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <h5 className="mt-5 mb-3 text-center">Progresso Semanal</h5>
      <div className="bg-black p-3 rounded shadow-sm">
        {progresso.map((habito, index) => (
          <div key={index} className="mb-3">
            <strong className="text-white">{habito.nome}</strong>
            <div className="d-flex gap-2 mt-2 flex-wrap">
              {habito.dias.map((dia, idx) => (
                <div
                  key={idx}
                  className="rounded"
                  style={{
                    width: 30,
                    height: 30,
                    backgroundColor: dia.concluido ? '#dc3545' : '#6c757d'
                  }}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

        {/*Botão de fogo fixo no canto*/}
      <Link
          to="/habitos"
          className="btn btn-danger rounded-circle position-fixed"
          style={{
            bottom: 20,
            right: 20,
            width: 56,
            height: 56,
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
          }}
        >
          <Flame size={28} color="#fff" />
        </Link>
    </div>    //</Container>
  );
}


