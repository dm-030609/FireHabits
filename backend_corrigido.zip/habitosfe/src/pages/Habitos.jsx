import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Button, Spinner, Navbar, Nav } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import {
  salvarMultiplosHabitos,
  listarHabitosLocal,
  removerHabitoLocal,
  salvarHabitoLocal,
} from '../../indexedDB';

function Habitos() {
  const [habitos, setHabitos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchHabitos = async () => {
      try {
        const res = await axios.get('http://localhost:3000/habitos');
        setHabitos(res.data);
        await salvarMultiplosHabitos(res.data); // cache local
      } catch (err) {
        console.warn('Falha ao buscar da API, tentando IndexedDB...');
        const locais = await listarHabitosLocal();
        setHabitos(locais);
        setError('Conectado via cache local');
      } finally {
        setLoading(false);
      }
    };

    fetchHabitos();
  }, []);

  const concluirHabito = async (id) => {
    try {
      await axios.put(`http://localhost:3000/habitos/${id}`, { status: 'Concluído' });
      setHabitos((prev) =>
        prev.map((h) => (h._id === id ? { ...h, status: 'Concluído' } : h))
      );
      await salvarHabitoLocal({ ...habitos.find((h) => h._id === id), status: 'Concluído' });
    } catch {
      alert('Erro ao concluir hábito');
    }
  };

  const excluirHabito = async (id) => {
    try {
      await axios.delete(`http://localhost:3000/habitos/${id}`);
      setHabitos(habitos.filter((h) => h._id !== id));
      await removerHabitoLocal(id);
    } catch {
      alert('Erro ao excluir hábito');
    }
  };

  return (
    <>
      <Navbar bg="dark" variant="dark" expand="lg" className="px-3">
        <Navbar.Brand as={Link} to="/" className="fw-bold text-danger">FireHabits</Navbar.Brand>
        <Navbar.Toggle />
        <Navbar.Collapse>
          <Nav className="ms-auto">
            <Nav.Link as={Link} to="/">Início</Nav.Link>
            <Nav.Link as={Link} to="/dashboard">Dashboard</Nav.Link>
            <Nav.Link as={Link} to="/criar">+ Novo Hábito</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Navbar>

      <Container className="py-4">
        <h2 className="text-danger mb-4 text-center">Meus Hábitos</h2>
        {loading && <div className="text-center"><Spinner animation="border" variant="danger" /></div>}
        {error && <div className="text-center text-warning">{error}</div>}

        <Row className="row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
          {habitos.map((habito) => (
            <Col key={habito._id}>
              <Card className="bg-dark text-white shadow-sm border-0 h-100">
                <Card.Body>
                  <Card.Title className="text-danger">{habito.nome}</Card.Title>
                  <Card.Text>{habito.descricao}</Card.Text>
                  <Card.Text><strong>Frequência:</strong> {habito.frequencia}</Card.Text>
                  <Card.Text><strong>Status:</strong> {habito.status}</Card.Text>
                  <div className="d-flex justify-content-end flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="outline-danger"
                      onClick={() => navigate(`/editar/${habito._id}`)}
                    >
                      Editar
                    </Button>
                    <Button
                      size="sm"
                      variant="outline-success"
                      disabled={habito.status === 'Concluído'}
                      onClick={() => concluirHabito(habito._id)}
                    >
                      Concluir
                    </Button>
                    <Button
                      size="sm"
                      variant="outline-light"
                      onClick={() => excluirHabito(habito._id)}
                    >
                      Excluir
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  );
}

export default Habitos;
